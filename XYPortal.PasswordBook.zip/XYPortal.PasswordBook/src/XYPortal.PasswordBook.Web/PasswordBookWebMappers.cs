using Riok.Mapperly.Abstractions;
using Volo.Abp.Mapperly;

namespace XYPortal.PasswordBook.Web;

/*
Write your mappings here...

[Mapper(RequiredMappingStrategy = RequiredMappingStrategy.Target)]
public partial class PasswordBookWebMappers : MapperBase<Book, BookDto>
{
    public override partial BookDto Map(Book source);

    public override partial void Map(Book source, BookDto destination);
}
*/